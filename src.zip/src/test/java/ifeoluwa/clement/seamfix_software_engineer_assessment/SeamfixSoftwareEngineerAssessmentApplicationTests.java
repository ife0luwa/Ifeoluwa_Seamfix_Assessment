package ifeoluwa.clement.seamfix_software_engineer_assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeamfixSoftwareEngineerAssessmentApplicationTests {

    @Test
    void contextLoads() {
    }

}
