package ifeoluwa.clement.seamfix_software_engineer_assessment.JSONpayload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ifeoluwa on 28/10/2022
 * @project
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BvnRequest {
    private String bvn;

}
